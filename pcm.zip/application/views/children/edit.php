<!-- new -->

<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>

<body>
    <?php $this->load->view('command/header'); ?>
    <div id="page">
        <div class="container">
            <br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="col-md-12">
                                <p style="width:100%;">
                                    <?php echo $this->session->flashdata('message');
                                    unset($_SESSION['message']); ?>
                                </p>
                            </div>
                            Edit child
                        </div>
                        <?php echo form_open_multipart("children/update"); ?>
                        <input type="hidden" id="id" name="id" value="<?= $id; ?>">

                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2">Name:</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="name" required="" value="<?= $name; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Age:</label>
                                <div class="col-sm-12">

                                    <select name="age" id="age" class="form-control">
                                        <option <?php if ('1' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="1">1</option>
                                        <option <?php if ('2' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="2">2</option>
                                        <option <?php if ('3' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="3">3</option>
                                        <option <?php if ('4' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="4">4</option>
                                        <option <?php if ('5' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="5">5</option>
                                        <option <?php if ('6' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="6">6</option>
                                        <option <?php if ('7' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="7">7</option>
                                        <option <?php if ('8' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="8">8</option>
                                        <option <?php if ('9' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="9">9</option>
                                        <option <?php if ('10' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="10">10</option>
                                        <option <?php if ('11' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="11">11</option>
                                        <option <?php if ('12' == $age) {
                                                    echo 'selected="selected"';
                                                } ?> value="12">12</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Entery Date:</label>
                                <div class="col-sm-12">
                                    <input type="date" class="form-control" id="birthdate" name="birthdate" placeholder="Entery Date" required="" value="<?= $birthdate; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Gender:</label>
                                <div class="col-sm-12">
                                    <select name="gender" class="form-control">
                                        <option <?php if ('male' == $gender) {
                                                    echo 'selected="selected"';
                                                } ?> value="male" selected="">Male</option>
                                        <option <?php if ('female' == $gender) {
                                                    echo 'selected="selected"';
                                                } ?> value="female">Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Height</label>
                                <div class="col-sm-12">
                                    <input type="number" class="form-control" id="height" name="height" placeholder="Height" required="" value="<?= $height; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Weight</label>
                                <div class="col-sm-12">
                                    <input type="number" class="form-control" id="weight" name="weight" placeholder="Weight" required="" value="<?= $weight; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>

    </div>



</body>

</html>