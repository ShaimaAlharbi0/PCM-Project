<!-- new -->

<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>

<body>
    <?php $this->load->view('command/header'); ?>
    <div id="page">
        <div class="container">

            <br>

            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="col-md-12">
                                <p style="width:100%;">
                                    <?php echo $this->session->flashdata('message');
                                    unset($_SESSION['message']); ?>
                                </p>
                            </div>
                            New child
                        </div>
                        <?php echo form_open_multipart("children/index"); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2">Name:</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Name" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Age:</label>
                                <div class="col-sm-12">
                                    <select name="age" id="age" class="form-control">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Entery Date:</label>
                                <div class="col-sm-12">
                                    <input type="date" class="form-control" id="birthdate" name="birthdate" placeholder="Entery Date" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Gender:</label>
                                <div class="col-sm-12">
                                    <select name="gender" class="form-control">
                                        <option value="male" selected="">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Height</label>
                                <div class="col-sm-12">
                                    <input type="number" class="form-control" id="height" name="height" placeholder="Height" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Weight</label>
                                <div class="col-sm-12">
                                    <input type="number" class="form-control" id="weight" name="weight" placeholder="Weight" required="">
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">

                    <br>
                    <div class="card">
                        <div class="card-header">
                            children
                        </div>

                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Height</th>
                                        <th>Weight</th>
                                        <th>Gender</th>
                                        <th>Entery Date</th>
                                        <th>Options</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($children as $dat) : ?>
                                        <tr>
                                            <td>
                                                <?php echo $dat->name; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->age; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->height; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->weight; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->gender; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->birthdate; ?>
                                            </td>
                                            <td>
                                                <?php echo anchor("children/edit/" . $dat->id, "Edit") ?>
                                                |
                                                <?php echo anchor("children/delete/" . $dat->id, "Delete", array('onclick' => "return confirm('Are you sure to delete this record?')")) ?>
                                            </td>

                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>

                            </table>
                        </div>

                    </div>

                </div>
            </div>
            <br>

            <?php $this->load->view('command/footer'); ?>
            <?php $this->load->view('command/script'); ?>

        </div>
    </div>



</body>

</html>