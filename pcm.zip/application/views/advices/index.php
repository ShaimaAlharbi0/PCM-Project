<!-- new -->

<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>

<body>
    <?php $this->load->view('command/header'); ?>
    <div id="page">
        <div class="container">

            <br>

            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="col-md-12">
                                <p style="width:100%;">
                                    <?php echo $this->session->flashdata('message');
                                    unset($_SESSION['message']); ?>
                                </p>
                            </div>
                            New advice
                        </div>
                        <?php echo form_open_multipart("advices/index"); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2">Title:</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="title" name="title" placeholder="Title" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Description:</label>
                                <div class="col-sm-12">
                                    <textarea class="form-control" id="description" name="description" rows="4" cols="50" placeholder="Description" required=""></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">

                    <br>
                    <div class="card">
                        <div class="card-header">
                            advices
                        </div>

                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th style="width: 500px;">Description</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($advices as $dat) : ?>
                                        <tr>
                                            <td>
                                                <?php echo $dat->title; ?>
                                            </td>
                                            <td>
                                                <?php echo $dat->description; ?>
                                            </td>
                                            <td>
                                                <?php echo anchor("advices/edit/" . $dat->id, "Edit") ?>
                                                |
                                                <?php echo anchor("advices/delete/" . $dat->id, "Delete", array('onclick' => "return confirm('Are you sure to delete this record?')")) ?>
                                            </td>

                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>

                            </table>
                        </div>

                    </div>

                </div>
            </div>
            <br>
        </div>
        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>


    </div>



</body>

</html>