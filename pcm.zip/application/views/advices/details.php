<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>
    <?php $this->load->view('command/header'); ?>

    <div id="page">

        <div class="breadcrumbs">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="bread"><span><a href="index.html">Home</a></span> / <span>Advice Details</span></p>
                    </div>
                </div>
            </div>
        </div>


        <div class="colorlib-product">
            <div class="container">
                <div class="row row-pb-lg product-detail-wrap">
                    <div class="col-sm-12">
                        <div class="product-desc">
                            <h3><?php echo $title; ?></h3>
                            <p><?php echo $description; ?>.</p>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>

    </div>



</body>

</html>