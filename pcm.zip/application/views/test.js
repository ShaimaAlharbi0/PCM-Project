//THIS CODE CALCULATES THE CALORIC NEEDS OF CHILDREN BASED ON  EQUATIONS AND TABLES PUBLISHED IN 2002 NUTRITIONAL RECOMMENDATIONS OF THE FOOD AND NUTRITION BOARD OF THE NATIONAL INSTITUTES OF HEALTH:
//EQUATION HAS BEEN MODIFIED TO ACCEPT DATA IN POUNDS AND INCHES RATHER THAN METRIC MEASURES
//THE MODIFIED BASE EQUATION IS:
//EER=SF-(AF*Age)+PA[(WF*wt in pounds)+HF(ht inches)] + EDF
//where SF is a factor based on Sex,
//AF is a factor based on age;
//PA is a sex-based factor for physical activity level;
//WF and HF and factors for weight and height;
//EDF is the factor for energy deposition (energy used to produce new lean or fat tissues)

// The main calculation function
function calcDCN(
  intWeight,
  strWeight,
  intHeight,
  strHeight,
  intAge,
  intMonth,
  strGender,
  strActivity,
  strOverweight
) {
  //Begin Data for TEE:  SF-(AF*Age)+PA[(WF*wt in pounds)+HF(ht inches)]

  //Assign Sex Factor (SF)
  var factorS;
  var factorSmnw = 88.5;
  var factorSmow = -114;
  var factorSfnw = 135.3;
  var factorSfow = 389;

  if (strOverweight == 'yes' && strGender == 'male') {
    factorS = factorSmow;
  } else if (strOverweight == 'no' && strGender == 'male') {
    factorS = factorSmnw;
  } else if (strOverweight == 'yes' && strGender == 'female') {
    factorS = factorSfow;
  } else if (strOverweight == 'no' && strGender == 'female') {
    factorS = factorSfnw;
  }

  //document.dcn.Result.value=parseInt(factorS);

  // Calculate: factorA or Age Factor  (Age-dependent adjustment factor * age in years)

  var factorA;
  var totalMonths = intAge * 12 + parseInt(intMonth);
  var moYear = totalMonths / 12;
  var factorAmnw = -61.9 * moYear;
  var factorAmow = -50.9 * moYear;
  var factorAfnw = -30.8 * moYear;
  var factorAfow = -41.2 * moYear;

  if (strOverweight == 'yes' && strGender == 'male') {
    factorA = factorAmow;
  } else if (strOverweight == 'no' && strGender == 'male') {
    factorA = factorAmnw;
  } else if (strOverweight == 'yes' && strGender == 'female') {
    factorA = factorAfow;
  } else if (strOverweight == 'no' && strGender == 'female') {
    factorA = factorAfnw;
  }
  //test age factor (factorA)
  //document.dcn.Result.value=parseInt(factorA);

  // Assign Physical Activity  Factor (PA)
  //PA factors for normal weight boys, 3 to 18 years  I=inactive; L=low activity; M=moderate activity; H=very active
  factorMNI = 1.0;
  factorMNL = 1.13;
  factorMNM = 1.26;
  factorMNH = 1.42;

  //PA factors for overweight boys, 3 to 18 years  I=inactive; L=low activity; M=moderate activity; H=very active
  factorMOI = 1.0;
  factorMOL = 1.12;
  factorMOM = 1.24;
  factorMOH = 1.45;

  //PA factors for normal weight girls, 3 to 18 years  I=inactive; L=low activity; M=moderate activity; H=very active
  factorFNI = 1.0;
  factorFNL = 1.16;
  factorFNM = 1.31;
  factorFNH = 1.56;

  //PA factors for overweight girls , 3 to 18 years  I=inactive; L=low activity; M=moderate activity; H=very active

  factorFOI = 1.0;
  factorFOL = 1.18;
  factorFOM = 1.35;
  factorFOH = 1.6;

  //dictates that EER equation uses PA factors for normal weight boys
  var malePA;
  if (strOverweight == 'no' && strActivity == 'inactive') {
    malePA = factorMNI;
  } else if (strOverweight == 'no' && strActivity == 'low') {
    malePA = factorMNL;
  } else if (strOverweight == 'no' && strActivity == 'moderate') {
    malePA = factorMNM;
  } else if (strOverweight == 'no' && strActivity == 'high') {
    malePA = factorMNH;
  }
  //dictates that EER equation uses  PA factors for overweight boys
  else if (strOverweight == 'yes' && strActivity == 'inactive') {
    malePA = factorMOI;
  } else if (strOverweight == 'yes' && strActivity == 'low') {
    malePA = factorMOL;
  } else if (strOverweight == 'yes' && strActivity == 'moderate') {
    malePA = factorMOM;
  } else if (strOverweight == 'yes' && strActivity == 'high') {
    malePA = factorMOH;
  }

  //dictates that EER equation uses  PA factors for normal weight girls
  var femalePA;
  if (strOverweight == 'no' && strActivity == 'inactive') {
    femalePA = factorFNI;
  } else if (strOverweight == 'no' && strActivity == 'low') {
    femalePA = factorFNL;
  } else if (strOverweight == 'no' && strActivity == 'moderate') {
    femalePA = factorFNM;
  } else if (strOverweight == 'no' && strActivity == 'high') {
    femalePA = factorFNH;
  }
  //dictates that EER equation uses  PA factors for overweight girls
  else if (strOverweight == 'yes' && strActivity == 'inactive') {
    femalePA = factorFOI;
  } else if (strOverweight == 'yes' && strActivity == 'low') {
    femalePA = factorFOL;
  } else if (strOverweight == 'yes' && strActivity == 'moderate') {
    femalePA = factorFOM;
  } else if (strOverweight == 'yes' && strActivity == 'high') {
    femalePA = factorFOH;
  }
  //PAfactor equation decision tree: gender--malePA or femalePA--
  var factorPA;
  if (strGender == 'male') {
    factorPA = malePA;
  } else if (strGender == 'female') {
    factorPA = femalePA;
  }
  //test javascript for PA factors
  //document.dcn.Result.value=parseFloat(factorPA);

  // Caluclate Weight Factor (WF) and Height Factor (HF)

  //Weight Factor
  //converts form input (pounds) into killograms

  //Weight Factor
  //converts form input (pounds) into killograms
  var convertWeight;
  var convertPounds = 0.4536;
  var convertKilograms = 1;

  if (strWeight == 'pounds') {
    convertWeight = convertPounds;
  } else if (strWeight == 'kg') {
    convertWeight = convertKilograms;
  }

  var convertKg = intWeight * convertWeight;

  //document.dcn.Result.value=convertKg;

  var factorW;
  var factorWmnw = 26.7 * convertKg;
  var factorWmow = 19.5 * convertKg;
  var factorWfnw = 10 * convertKg;
  var factorWfow = 15 * convertKg;

  if (strOverweight == 'yes' && strGender == 'male') {
    factorW = factorWmow;
  } else if (strOverweight == 'no' && strGender == 'male') {
    factorW = factorWmnw;
  } else if (strOverweight == 'yes' && strGender == 'female') {
    factorW = factorWfow;
  } else if (strOverweight == 'no' && strGender == 'female') {
    factorW = factorWfnw;
  }
  //test factor
  //document.dcn.Result.value=parseInt(factorW);

  //Height factor
  //converts form input ( inches or cm)  into Meters

  var factorM;
  var factorInches = 0.0254;
  var factorCm = 0.01;
  var factorErr = 1;

  if (strHeight == 'cm') {
    factorM = factorCm;
  } else if (strHeight == 'inches') {
    factorM = factorInches;
  } else {
    factorM = factorErr;
  }

  var convertM = parseFloat(intHeight) * factorM;

  //test conversion
  //document.dcn.Result.value=convertM;

  var factorH;
  var factorHmnw = 903 * convertM;
  var factorHmow = 1161.4 * convertM;
  var factorHfnw = 934 * convertM;
  var factorHfow = 701.6 * convertM;

  if (strOverweight == 'yes' && strGender == 'male') {
    factorH = factorHmow;
  } else if (strOverweight == 'no' && strGender == 'male') {
    factorH = factorHmnw;
  } else if (strOverweight == 'yes' && strGender == 'female') {
    factorH = factorHfow;
  } else if (strOverweight == 'no' && strGender == 'female') {
    factorH = factorHfnw;
  }
  //test factor
  //document.dcn.Result.value=parseFloat(factorH);

  //end TEE calculations

  // Assign Energy Deposition Factor (EDF)
  //calories needed for energy deposition are age (over 9 years=25; under=20) and weight dependent (if overweight, 0 calories allocated for energy depostion)
  var factorED;
  var factorEDnine = 25;
  var factorEDeight = 20;
  var factorEDow = 0;

  if (strOverweight == 'yes') {
    factorED = factorEDow;
  } else if (intAge >= 9) {
    factorED = factorEDnine;
  } else {
    factorED = factorEDeight;
  }

  //  Calculate EER = TEE + EDF == Total Energy Needs
  //calculate  PA= factorPA*factorW + factorPA*factorH

  //varible designed to test PA values inform
  //var factorPA2=factorPA*100

  var factorPAH = factorPA * factorH;
  var factorPAW = factorPA * factorW;
  var factorPAHW = factorPAH + factorPAW;

  //document.dcn.Result.value=parseInt(factorPAH);

  var factorTEE = factorS + factorA + factorPAHW;

  var totalEER = factorTEE + factorED;

  // Write the result to the text box
  document.dcn.Result.value = parseInt(totalEER);
}

//end script
