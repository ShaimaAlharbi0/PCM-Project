<footer id="colorlib-footer" role="contentinfo">
  <div class="container">
    <div class="row row-pb-md">
      <div class="col footer-col colorlib-widget">
        <h4>About care</h4>
        <p>A parental control application focuses on monitoring and managing children's digital
          activity. Parental control software filters material establishes standards for correct usage
          and works limit access to certain programs.</p>

      </div>


      <div class="col footer-col">
        <h4>Contact Information</h4>
        <ul class="colorlib-footer-links">
          <li>Riyadh, <br> Saudi Arabia</li>
          <li><a href="tel://055555555">055555555</a></li>
          <li><a href="mailto:info@care.com">info@care.com</a></li>
          <li><a href="#">care.com</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="copy">
    <div class="row">
      <div class="col-sm-12 text-center">
        <p>
          <span>
            Copyright &copy;
            <script>
              document.write(new Date().getFullYear());
            </script> All rights reserved
          </span>

        </p>
      </div>
    </div>
  </div>
</footer>

<div class="gototop js-top">
  <a href="#" class="js-gotop"><i class="ion-ios-arrow-up"></i></a>
</div>