<!-- <div id="preloder">
  <div class="loader"></div>
</div>


<header class="header-section">
  <div class="header-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-2 text-center text-lg-left">
          <a href="./index.html" class="site-logo">
            <img src="<?= base_url(); ?>includes/img/logo.png" alt="">
          </a>
        </div>
        <div class="col-xl-7 col-lg-5">

        </div>
        <div class="col-xl-3 col-lg-5">
          <div class="user-panel">
            <div class="up-item">

              <?php if ($this->ion_auth->logged_in()) { ?>
                <i class="flaticon-profile"></i>
                <a href="<?php echo site_url('auth/profile'); ?>">Profile</a>
                <i class="flaticon-logout"></i>
                <a href="<?php echo site_url('auth/logout'); ?>">Logout</a>
              <?php } else { ?>
                <i class="flaticon-unlock"></i>
                <a href="<?php echo site_url('auth/login'); ?>">Login</a>
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="main-navbar">
    <div class="container">
      <ul class="main-menu">
        <li><a href="<?php echo site_url('home/'); ?>">Home</a></li>
        <li><a href="<?php echo site_url('home/foods'); ?>">food</a></li>
        <?php if ($this->ion_auth->logged_in()) { ?>
          <?php if ($this->ion_auth->is_admin()) { ?>
            <li> <a href="<?php echo site_url('foods'); ?>">food Management</a></li>
            <li> <a href="<?php echo site_url('auth/coaches'); ?>">Coaches</a></li>
            <li> <a href="<?php echo site_url('packages'); ?>">Packages</a></li>
            <li> <a href="<?php echo site_url('home/stat'); ?>">Statistics</a></li>
          <?php }  ?>
          <?php if ($this->ion_auth->is_users()) { ?>
            <li> <a href="<?php echo site_url('subscriptions'); ?>">Subscriptions</a></li>
            <li> <a href="<?php echo site_url('subscriptions/checkout'); ?>">Cart</a></li>
          <?php }  ?>
          <li> <a href="<?php echo site_url('tickets'); ?>">Tickets</a></li>

        <?php }  ?>
      </ul>
    </div>
  </nav>
</header> -->

<div class="colorlib-loader"></div>

<nav class="colorlib-nav" role="navigation">
  <div class="top-menu">
    <div class="container">
      <div class="row">
        <div class="col-sm-7 col-md-9">
          <div id="colorlib-logo"><a href="<?php echo site_url('home/index'); ?>"><img width="150" src="<?= base_url(); ?>includes/images/logo.png" alt=""></a></div>
        </div>
        <div class="col-sm-5 col-md-3">
          <ul>
            <?php if ($this->ion_auth->logged_in()) { ?>
              <i class="flaticon-profile"></i>
              <a href="<?php echo site_url('auth/profile'); ?>">Profile</a> |
              <i class="flaticon-logout"></i>
              <a href="<?php echo site_url('auth/logout'); ?>">Logout</a>
            <?php } else { ?>
              <i class="flaticon-unlock"></i>
              <a href="<?php echo site_url('auth/login'); ?>">Login</a>
            <?php } ?>
          </ul>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12 text-left menu-1">
          <ul>
            <li class="active"><a href="<?php echo site_url('home/index'); ?>">Home</a></li>
            <?php if ($this->ion_auth->is_admin()) { ?>
              <li> <a href="<?php echo site_url('foods'); ?>">Foods Management</a></li>
              <li> <a href="<?php echo site_url('advices'); ?>">Advices</a></li>
            <?php }  ?>
            <?php if ($this->ion_auth->is_users()) { ?>
              <li> <a href="<?php echo site_url('children'); ?>">Children control</a></li>
            <?php }  ?>
            <?php if ($this->ion_auth->logged_in()) { ?>
              <li> <a href="<?php echo site_url('home/calories'); ?>">Calorie Calculator</a></li>
            <?php }  ?>
            <li><a href="<?php echo site_url('home/about'); ?>">About</a></li>

          </ul>
        </div>
      </div>
    </div>
  </div>

  <div class="sale">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 offset-sm-2 text-center">
          <div class="row">
            <div class="owl-carousel2">
              <?php
              $advices = $this->session->userdata('advice');
              foreach ($advices as $row) : ?>
                <div class="item">
                  <div class="col">
                    <h3><a href="<?= base_url(); ?>advices/details/<?php echo $row->id; ?>"><?php echo $row->title; ?></a></h3>
                  </div>
                </div>
              <?php endforeach; ?>
              <!-- <div class="item">
                <div class="col">
                  <h3><a href="#">Test Advice</a></h3>
                </div>
              </div>
              <div class="item">
                <div class="col">
                  <h3><a href="#">Test Advice 2</a></h3>
                </div>
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</nav>