<script src="<?= base_url(); ?>includes/js/jquery.min.js"></script>
<!-- popper -->
<script src="<?= base_url(); ?>includes/js/popper.min.js"></script>
<!-- bootstrap 4.1 -->
<script src="<?= base_url(); ?>includes/js/bootstrap.min.js"></script>
<!-- jQuery easing -->
<script src="<?= base_url(); ?>includes/js/jquery.easing.1.3.js"></script>
<!-- Waypoints -->
<script src="<?= base_url(); ?>includes/js/jquery.waypoints.min.js"></script>
<!-- Flexslider -->
<script src="<?= base_url(); ?>includes/js/jquery.flexslider-min.js"></script>
<!-- Owl carousel -->
<script src="<?= base_url(); ?>includes/js/owl.carousel.min.js"></script>
<!-- Magnific Popup -->
<script src="<?= base_url(); ?>includes/js/jquery.magnific-popup.min.js"></script>
<script src="<?= base_url(); ?>includes/js/magnific-popup-options.js"></script>
<!-- Date Picker -->
<script src="<?= base_url(); ?>includes/js/bootstrap-datepicker.js"></script>
<!-- Stellar Parallax -->
<script src="<?= base_url(); ?>includes/js/jquery.stellar.min.js"></script>
<!-- Main -->
<script src="<?= base_url(); ?>includes/js/main.js"></script>