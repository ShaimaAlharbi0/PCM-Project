<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>
    <?php $this->load->view('command/header'); ?>

    <section class="product-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="product-pic-zoom">
                        <img class="product-big-img" src="https://www.verywellfit.com/thmb/2OPDRfV4xAB1J3zKourxCgY5hqQ=/1333x1000/smart/filters:no_upscale()/Dumbbells-568094543df78ccc15a5b493.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 product-details">
                    <h2 class="p-title"><?php echo $title ?></h2>
                    <h3 class="p-price"><?php echo $price ?></h3>
                    <?php if ($this->ion_auth->logged_in()) { ?>
                        <?php if (!$this->ion_auth->is_admin()) { ?>
                            <?php echo form_open_multipart("subscriptions/post"); ?>
                            <input type="hidden" class="form-control" id="id" name="id" value="<?= $id; ?>">
                            <input type="hidden" class="form-control" id="price" name="price" value="<?= $price; ?>">
                            <input type="hidden" class="form-control" id="duration" name="duration" value="<?= $duration; ?>">
                            <button type="submit" class="site-btn">SHOP NOW</button>
                            <?php echo form_close(); ?>

                        <?php }  ?>
                    <?php }  ?>

                    <div id="accordion" class="accordion-area">
                        <div class="panel">
                            <div class="panel-header" id="headingOne">
                                <button class="panel-link active" data-toggle="collapse" data-target="#collapse1" aria-expanded="true" aria-controls="collapse1">description</button>
                            </div>
                            <div id="collapse1" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="panel-body">
                                    <p><?php echo $description ?>.</p>
                                </div>
                            </div>
                        </div>
                        <div class="panel">
                            <div class="panel-header" id="headingTwo">
                                <button class="panel-link" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">information </button>
                            </div>
                            <div id="collapse2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="panel-body">
                                    <p><?php echo $type ?></p>
                                    <p><?php echo $category ?></p>
                                    <p><?php echo $duration ?> Months</p>
                                </div>
                            </div>
                        </div>
                        <!-- <?php if ($type == 'Special') { ?>
                            <div class="panel">
                                <div class="panel-header" id="headingThree">
                                    <button class="panel-link" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse3">coach</button>
                                </div>
                                <div id="collapse3" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                    <div class="panel-body">
                                        <p><?php echo $first_name ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php } ?> -->
                        <div class="panel">
                            <div class="panel-header" id="headingFour">
                                <button class="panel-link" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4">Sessions</button>
                            </div>
                            <div id="collapse4" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                <div class="panel-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Session</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($packages as $dat) : ?>
                                                <tr>
                                                    <td>
                                                        <?php echo $dat->notes; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

    <?php $this->load->view('command/footer'); ?>
    <?php $this->load->view('command/script'); ?>


</body>

</html>