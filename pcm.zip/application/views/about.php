<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>
	<?php $this->load->view('command/header'); ?>

	<div id="page">

		<div class="breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col">
						<p class="bread"><span><a href="index.html">Home</a></span> / <span>About us</span></p>
					</div>
				</div>
			</div>
		</div>


		<div class="container">
			<div class="row">
				<h2>About care</h2>
				<p>A parental control application focuses on monitoring and managing children's digital activity. Parental control software filters material establishes standards for correct usage and works limit access to certain programs.</p>
				<h3>If you have any questions please feel free to contact us anytime</h3>
			</div>
			<div class="row">
				<p>Email: <b>info@care.com</b></p>
			</div>
			<div class="row">
				<p>Mobile: <b>0555555555</b></p>
			</div>
		</div>

		<?php $this->load->view('command/footer'); ?>
		<?php $this->load->view('command/script'); ?>

	</div>



</body>

</html>