<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>

	<div id="page">
		<?php $this->load->view('command/header'); ?>

		<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
					<li style="background-image: url(<?= base_url(); ?>includes/images/1.jpg);">
						<div class="overlay"></div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-6 offset-sm-3 text-center slider-text">
									<div class="slider-text-inner">
									</div>
								</div>
							</div>
						</div>
					</li>
					<li style="background-image: url(<?= base_url(); ?>includes/images/3.jpg);">
						<div class="overlay"></div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-6 offset-sm-3 text-center slider-text">
									<div class="slider-text-inner">

									</div>
								</div>
							</div>
						</div>
					</li>
					<li style="background-image: url(<?= base_url(); ?>includes/images/2.jpg);">
						<div class="overlay"></div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-6 offset-sm-3 text-center slider-text">
									<div class="slider-text-inner">

									</div>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</aside>
		<div class="colorlib-intro">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2 class="intro">Parental Control Application For The Nutritional Needs Of Children.</h2>
					</div>
				</div>
			</div>
		</div>

		<div class="colorlib-product">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 offset-sm-2 text-center colorlib-heading">
						<h2>Best Foods</h2>
					</div>
				</div>
				<div class="row row-pb-md">
					<?php foreach ($food as $data) : ?>
						<div class="col-lg-3 mb-4 text-center">
							<div class="product-entry border">
								<a href="<?= base_url(); ?>home/food/<?php echo $data->id; ?>" class="prod-img">
									<img src="<?php echo $data->photo; ?>" class="img-fluid" alt="Free html5 bootstrap 4 template">
								</a>
								<div class="desc">
									<h2><a href="<?= base_url(); ?>home/food/<?php echo $data->id; ?>"><?php echo $data->title; ?></a></h2>

								</div>
							</div>
						</div>
					<?php endforeach; ?>


				</div>
			</div>
		</div>

		<?php $this->load->view('command/footer'); ?>
		<?php $this->load->view('command/script'); ?>

	</div>
</body>

</html>