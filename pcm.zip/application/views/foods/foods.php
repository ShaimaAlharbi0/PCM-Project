<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>
    <div id="page">
        <?php $this->load->view('command/header'); ?>

        <section class="category-section spad">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12  order-1 order-lg-2 mb-5 mb-lg-0">
                        <div class="row">
                            <?php foreach ($foods as $dat) : ?>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="product-item">
                                        <div class="pi-pic">
                                            <a href="<?= base_url(); ?>foods/details/<?php echo $dat->id; ?>">
                                                <img src="<?php echo $dat->photo; ?>" height="300" alt="">
                                            </a>

                                        </div>
                                        <div class="pi-text">
                                            <p> <?php echo $dat->title; ?></p>
                                            <p>Number: <?php echo $dat->num; ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>


                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>

    </div>
</body>

</html>