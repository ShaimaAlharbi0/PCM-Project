<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>
    <div id="page">
        <?php $this->load->view('command/header'); ?>

        <section class="product-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="product-pic-zoom">
                            <img class="product-big-img" src="<?= $photo; ?>" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 product-details">
                        <h2 class="p-title"><?= $title; ?></h2>

                        <div id="accordion" class="accordion-area">
                            <div class="panel">
                                <div class="panel-header" id="headingOne">
                                    <button class="panel-link active" data-toggle="collapse" data-target="#collapse1" aria-expanded="true" aria-controls="collapse1">Description</button>
                                </div>
                                <div id="collapse1" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                    <div class="panel-body">
                                        <p><?= $description; ?></p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>

    </div>
</body>

</html>