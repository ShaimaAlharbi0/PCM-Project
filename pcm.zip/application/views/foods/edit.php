<!-- new -->

<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>

<body>
    <div id="page">
        <?php $this->load->view('command/header'); ?>

        <div class="container">
            <br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="col-md-12">
                                <p style="width:100%;">
                                    <?php echo $this->session->flashdata('message');
                                    unset($_SESSION['message']); ?>
                                </p>
                            </div>
                            Edit food
                        </div>
                        <?php echo form_open_multipart("foods/update"); ?>
                        <input type="hidden" id="id" name="id" value="<?= $id; ?>">
                        <input type="hidden" id="photo2" name="photo2" value="<?= $photo2; ?>">

                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label col-sm-2">Title:</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="title" name="title" placeholder="Title" required="" value="<?= $title; ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Description:</label>
                                <div class="col-sm-12">
                                    <textarea class="form-control" id="description" name="description" rows="4" cols="50" placeholder="Description" required=""><?= $description; ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Photo</label>
                                <div class="col-sm-12">
                                    <input type="file" class="form-control" id="photo" name="photo">
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>


    </div>


</body>

</html>