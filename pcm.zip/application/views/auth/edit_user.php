<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('command/head'); ?>

<body>
      <?php $this->load->view('command/header'); ?>

      <div class="container">

            <br>

            <div class="row">
                  <div class="col-md-12">
                        <div class="card card-primary">
                              <div class="card-header">
                                    <div class="col-md-12">
                                          <p style="width:100%;">
                                                <?php echo $this->session->flashdata('message');
                                                unset($_SESSION['message']); ?>
                                          </p>
                                    </div>
                                    Edit User
                              </div>
                              <?php echo form_open(uri_string()); ?>
                              <div class="card-body">
                                    <div class="form-group">
                                          <label class="control-label col-sm-2">Name:</label>
                                          <div class="col-sm-12">
                                                <?php echo form_input($first_name); ?>
                                          </div>
                                    </div>
                                    <div class="form-group">
                                          <label class="control-label col-sm-2">Phone:</label>
                                          <div class="col-sm-12">
                                                <?php echo form_input($phone); ?>
                                          </div>
                                    </div>
                                    <div class="form-group">
                                          <label class="control-label col-sm-2">Email:</label>
                                          <div class="col-sm-12">
                                                <?php echo form_input($email); ?>
                                          </div>
                                    </div>
                                    <div class="form-group">
                                          <label class="control-label col-sm-2">Password:</label>
                                          <div class="col-sm-12">
                                                <?php echo form_input($password); ?>
                                          </div>
                                    </div>
                                    <div class="form-group">
                                          <label class="control-label col-sm-2">Confirm Password:</label>
                                          <div class="col-sm-12">
                                                <?php echo form_input($password_confirm); ?>
                                          </div>
                                    </div>
                              </div>

                              <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                              </div>
                              <?php echo form_hidden('id', $user->id); ?>
                              <?php echo form_hidden($csrf); ?>
                              <?php echo form_close(); ?>
                        </div>
                  </div>
            </div>

            <br>
      </div>
      <?php $this->load->view('command/footer'); ?>
      <?php $this->load->view('command/script'); ?>

</body>

</html>