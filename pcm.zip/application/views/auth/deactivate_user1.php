<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('head'); ?>

<body>
    <?php $this->load->view('header'); ?>
    <?php $this->load->view('nav'); ?>

    <div id="wrapper" class="site-section">
        <div class="container">
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">deactivate</h3>
                                </div>
                                <?php echo form_open("auth/deactivate1/" . $user->id); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="control-label col-sm-12" for="email">>Are you sure to deactivate this user?</label>

                                    </div>
                                    <div class="form-group">
                                        <?php echo 'yes'; ?>
                                        <input type="radio" name="confirm" value="yes" checked="checked" />
                                        <?php echo 'no'; ?>
                                        <input type="radio" name="confirm" value="no" />
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <!-- <?php echo form_hidden($csrf); ?> -->
                                    <?php echo form_hidden(['id' => $user->id]); ?>
                                    <button type="submit" class="btn btn-primary">confirm</button>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <?php $this->load->view('footer'); ?>
    <?php $this->load->view('script'); ?>
</body>

</html>