<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('command/head'); ?>

<body>


	<div id="page">
		<?php $this->load->view('command/header'); ?>

		<div class="page-top-info">
			<div class="container">
				<h4>Account</h4>
				<div class="site-pagination">
					<a href="">Profile</a>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="row form-group">
						<div class="col-md-12">
							<p style="width:100%;">
								<?php echo $this->session->flashdata('message');
								unset($_SESSION['message']); ?>
							</p>
						</div>
					</div>
					<div class="card card-primary">
						<div class="card-header">
							<h3 class="card-title">Edit Profile</h3>
						</div>
						<?php echo form_open("auth/profile"); ?>
						<div class="card-body">
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Name:</label>
								<div class="col-sm-12">
									<?php echo form_input($first_name); ?>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Current Email :</label>
								<div class="col-sm-12">
									<input type="text" class="form-control" id="email2" name="email2" placeholder="Current Email" value="<?php echo $user->email ?>" readonly>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">New Email:</label>
								<div class="col-sm-12">
									<?php echo form_input($identity); ?>
								</div>
							</div>
							<div class="form-group">
								<label class="control-label col-sm-2" for="email">Password:</label>
								<div class="col-sm-12">
									<?php echo form_input($password2); ?>
								</div>
							</div>
							<!-- <div class="form-group">
										<label class="control-label col-sm-2" for="email">تأكيد كلمة المرور:</label>
										<div class="col-sm-12">
											<?php echo form_input($password_confirm); ?>
										</div>
									</div> -->
						</div>
						<!-- /.card-body -->
						<div class="card-footer">
							<button type="submit" class="btn btn-primary">Save</button>
						</div>
						<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

						<?php echo form_hidden('id', $user->id); ?>
						<!-- <?php echo form_hidden($csrf); ?> -->
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
		<?php $this->load->view('command/footer'); ?>
		<?php $this->load->view('command/script'); ?>
	</div>

</body>

</html>