<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>

<body>

  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <?php $this->load->view('command/menu'); ?>


    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>User</th>
                <th>Phone</th>
                <th>Email</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($users as $user) : ?>
                <tr>
                  <td><?php echo $user->first_name; ?></td>
                  <td><?php echo $user->phone; ?></td>
                  <td><?php echo $user->email; ?></td>
                  <td><?php echo ($user->active) ? anchor("auth/deactivate1/" . $user->id, 'Deactivate') : anchor("auth/activate1/" . $user->id, 'Activate'); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot>
              <tr>
                <th>User</th>
                <th>Phone</th>
                <th>Email</th>
                <th></th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>



    <?php $this->load->view('command/footer'); ?>
  </div>

  <?php $this->load->view('command/script'); ?>

</body>

</html>