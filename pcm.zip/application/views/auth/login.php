<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>

  <div id="page">
    <?php $this->load->view('command/header'); ?>

    <div class="page-top-info">
      <div class="container">
        <h4>Account</h4>
        <div class="site-pagination">
          <a href="">Login</a>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-md-5">
          <div class="p-4 mb-3 bg-white">
            <img src="<?= base_url(); ?>includes/images/3.jpg" alt="Image" class="img-fluid mb-4 rounded">
          </div>
        </div>
        <div class="col-md-7 mb-5">

          <?php echo form_open("auth/login"); ?>
          <div class="row form-group">
            <div class="col-md-12">
              <p style="width:100%;">
                <?php echo $this->session->flashdata('message');
                unset($_SESSION['message']); ?>
              </p>
            </div>
          </div>
          <div class="row form-group">

            <div class="col-md-12">
              <label class="text-black" for="email">Email</label>
              <?php echo form_input($email); ?>
              <!-- <input type="email" id="identity" name="identity" placeholder="Email" class="form-control" required=""> -->
            </div>
          </div>

          <div class="row form-group">

            <div class="col-md-12">
              <label class="text-black" for="subject">Password</label>
              <?php echo form_input($password); ?>
              <!-- <input type="password" id="password" name="password" placeholder="Password" class="form-control" required=""> -->
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-8">
              <input type="submit" value="Login" class="btn btn-primary py-2 px-4 text-white">
            </div>
            <div class="col-md-4">
              <a href="<?= base_url(); ?>auth/register">Join us</a>
            </div>
          </div>
          <?php echo form_close(); ?>


        </div>
      </div>
    </div>


    <?php $this->load->view('command/footer'); ?>
    <?php $this->load->view('command/script'); ?>


  </div>
</body>

</html>