<!-- new -->

<!DOCTYPE html>
<html lang="en">
<?php $this->load->view('command/head'); ?>

<body>
    <?php $this->load->view('command/header'); ?>

    <div class="container">

        <br>

        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <div class="col-md-12">
                            <p style="width:100%;">
                                <?php echo $this->session->flashdata('message');
                                unset($_SESSION['message']); ?>
                            </p>
                        </div>
                        New Coach
                    </div>
                    <?php echo form_open_multipart("auth/createCoach"); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="control-label col-sm-2">Name:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($first_name); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Phone:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($phone); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Email:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($email); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Specialization:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($specialization); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Experience:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($experience); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Avatar:</label>
                            <div class="col-sm-12">
                                <input type="file" class="form-control" id="file" name="file">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Description:</label>
                            <div class="col-sm-12">
                                <textarea class="form-control" id="description" name="description" rows="4" cols="50" placeholder="Description" required="">

                                </textarea>
                            </div>
                        </div>
                        <!-- <div class="form-group">
                            <label class="control-label col-sm-2">Password:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($password); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2">Confirm Password:</label>
                            <div class="col-sm-12">
                                <?php echo form_input($password_confirm); ?>
                            </div>
                        </div> -->
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">

                <br>
                <div class="card">
                    <div class="card-header">
                        Coaches
                    </div>

                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Specialization</th>
                                    <th>Experience</th>
                                    <th>Avatar</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user) : ?>
                                    <tr>
                                        <td><?php echo $user->first_name; ?></td>
                                        <td><?php echo $user->phone; ?></td>
                                        <td><?php echo $user->email; ?></td>
                                        <td><?php echo $user->specialization; ?></td>
                                        <td><?php echo $user->experience; ?></td>
                                        <td><img src="<?php echo $user->avatar; ?>" height="150"></td>
                                        <td>
                                            <?php echo anchor("auth/edit_coach/" . $user->id, "Edit") ?>
                                        </td>
                                        <!-- <td><?php echo ($user->active) ? anchor("auth/deactivate/" . $user->id, 'Deactivate') : anchor("auth/activate/" . $user->id, 'Activate'); ?>
                                            |
                                           
                                        </td> -->
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
    <?php $this->load->view('command/footer'); ?>
    <?php $this->load->view('command/script'); ?>

</body>

</html>