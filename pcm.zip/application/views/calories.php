<!DOCTYPE html>
<html lang="en">

<?php $this->load->view('command/head'); ?>


<body>

    <div id="page">
        <?php $this->load->view('command/header'); ?>

        <div class="breadcrumbs">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="bread"><span><a href="index.html">Home</a></span> / <span>Calorie Calculator</span></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">

            <br>

            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="col-md-12">
                                <p style="width:100%;">
                                    <?php echo $this->session->flashdata('message');
                                    unset($_SESSION['message']); ?>
                                </p>
                            </div>
                            Calorie Calculator
                        </div>
                        <?php echo form_open_multipart("home/postCalories"); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label col-sm-4">Child:</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="child_id" id="child_id" required="">
                                        <option selected value="">Select child</option>
                                        <?php foreach ($children as $dat) : ?>
                                            <option <?php if ($dat->id == $child_id) {
                                                        echo 'selected="selected"';
                                                    } ?> value="<?php echo $dat->id; ?>"><?php echo $dat->name; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <!-- <div class="form-group">
                                <label class="control-label col-sm-4">Gender:</label>
                                <div class="col-sm-12">
                                    <select name="gender" class="form-control">
                                        <option value="male" selected="">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                    <input type="hidden" name="gender" id="gender">
                                    <p id="gender1"></p>
                                </div>
                            </div> -->
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-4">Gender:</label>
                                        <div class="col-sm-12">
                                            <!-- <input type="hidden" name="months" id="months" value="0"> -->
                                            <input type="hidden" name="gender" id="gender">
                                            <p style="color:#ff0000;" id="gender1"><?php echo $gender ?></p>
                                            <!-- <input type="number" id="months" name="months" class="form-control" placeholder="Months" required="" min="0" max="11" value="0"> -->
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-4">Age:</label>
                                        <div class="col-sm-12">
                                            <!-- <input type="number" id="age" name="age" class="form-control" placeholder="Years" required="" min="1" max="12" value="1"> -->
                                            <input type="hidden" name="age" id="age">
                                            <p style="color:#ff0000;" id="age1"><?php echo $age ?></p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-4">Height:</label>
                                        <div class="col-sm-12">
                                            <input type="hidden" name="height" id="height">
                                            <p style="color:#ff0000;" id="height1"><?php echo $height ?></p>

                                            <!-- <input type="number" class="form-control" id="height" name="height" placeholder="Height" required="" min="40" max="150" value="40"> -->
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-4">Weight:</label>
                                        <div class="col-sm-12">
                                            <input type="hidden" name="weight" id="weight">
                                            <p style="color:#ff0000;" id="weight1"><?php echo $weight ?></p>
                                            <!-- <input type="number" id="wight" name="weight" class="form-control" placeholder="Weight" required="" min="2" max="25" value="2"> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-12">How active is the child?</label>
                                        <div class="col-sm-12">
                                            <select name="activity" class="form-control">
                                                <option value="inactive" selected="">Couch Potato</option>
                                                <option value="low">Low Active</option>
                                                <option value="moderate">Active </option>
                                                <option value="high">Very Active </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="control-label col-sm-12">Is the child overweight?</label>
                                        <div class="col-sm-12">
                                            <select name="overweight" class="form-control">
                                                <option value="no" selected="">no</option>
                                                <option value="yes">yes</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-12">
                                        <label class="control-label col-sm-12">Estimated Energy Needs: </label>
                                        <div class="col-sm-12">
                                            <p style="color:#ff0000;"><b><?php echo $total ?></b> Calories Per Day</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label col-sm-12">Breakfast: </label>
                                        <div class="col-sm-12">
                                            <p style="color:#ff0000;"><b><?php echo $breakfast ?></b> Calories</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label col-sm-12">Lunch: </label>
                                        <div class="col-sm-12">
                                            <p style="color:#ff0000;"><b><?php echo $lunch ?></b> Calories</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label col-sm-12">Dinner: </label>
                                        <div class="col-sm-12">
                                            <p style="color:#ff0000;"><b><?php echo $dinner ?></b> Calories</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="control-label col-sm-12">Snacks: </label>
                                        <div class="col-sm-12">
                                            <p style="color:#ff0000;"><b><?php echo $snacks ?></b> Calories</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Calculator</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>

            <br>
        </div>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

        <script>
            $(document).ready(function() {

                $("#child_id").change(function() {
                    var id = $("#child_id").val();
                    $.ajax({
                        url: '<?= base_url() ?>Children/getDetails',
                        method: 'post',
                        data: {
                            id: id
                        },
                        dataType: 'json',
                        success: function(response) {
                            console.log(response);
                            $("#gender").val(response[0].gender);
                            $("#gender1").text(response[0].gender);
                            $('#gender1').css('textTransform', 'capitalize');
                            $("#age").val(response[0].age);
                            $("#age1").text(response[0].age);
                            $("#height").val(response[0].height);
                            $("#height1").text(response[0].height);
                            $("#weight").val(response[0].weight);
                            $("#weight1").text(response[0].weight);
                        }
                    });
                });

            });
        </script>
        <?php $this->load->view('command/footer'); ?>
        <?php $this->load->view('command/script'); ?>

    </div>
</body>

</html>