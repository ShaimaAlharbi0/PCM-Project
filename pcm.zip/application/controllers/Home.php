<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->database();
		$this->load->library(array('ion_auth', 'form_validation'));
		$this->load->helper(array('url', 'language'));
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
		$this->lang->load('auth');
		$this->load->model('advice');
		$this->load->model('child');
		$this->load->model('food');
		$this->load->library('session');
	}

	public function index()
	{
		$this->data['food'] = $this->food->all();
		$this->data['advice'] = $this->advice->all();
		$this->session->set_userdata('advice', $this->advice->all());

		$this->load->view('home', $this->data);
	}

	public function calories()
	{
		$id = $this->ion_auth->get_user_id();
		$this->data['children'] = $this->child->getByUser($id);
		$this->data['lunch'] = 0;
		$this->data['dinner'] = 0;
		$this->data['breakfast'] = 0;
		$this->data['snacks'] = 0;
		$this->data['total'] = 0;
		$this->data['gender'] = '';
		$this->data['age'] = 0;
		$this->data['weight'] = 0;
		$this->data['height'] = 0;
		$this->data['child_id'] = '';
		$this->load->view('calories', $this->data);
	}

	public function postCalories()
	{

		$id = $this->ion_auth->get_user_id();
		$this->data['children'] = $this->child->getByUser($id);
		// $this->form_validation->set_rules('gender', 'gender', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('age', 'age', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('months', 'months', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('height', 'height', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('weight', 'weight', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('activity', 'activity', 'required', array('required' => 'required'));
		// $this->form_validation->set_rules('overweight', 'overweight', 'required', array('required' => 'required'));

		// if ($this->form_validation->run() == true) {
		$strGender = $this->input->post('gender');
		$intAge = floatval($this->input->post('age'));
		// $intMonth = $this->input->post('months');
		$intMonth = 0;
		$intHeight = floatval($this->input->post('height'));
		$intWeight = floatval($this->input->post('weight'));
		$strActivity = $this->input->post('activity');
		$strOverweight = $this->input->post('overweight');
		$strWeight = 'kg';
		$strHeight = 'cm';


		$factorS = 0;
		$factorSmnw = 88.5;
		$factorSmow = -114;
		$factorSfnw = 135.3;
		$factorSfow = 389;

		if ($strOverweight == 'yes' && $strGender == 'male') {
			$factorS = $factorSmow;
		} else if ($strOverweight == 'no' && $strGender == 'male') {
			$factorS = $factorSmnw;
		} else if ($strOverweight == 'yes' && $strGender == 'female') {
			$factorS = $factorSfow;
		} else if ($strOverweight == 'no' && $strGender == 'female') {
			$factorS = $factorSfnw;
		}

		$factorA = 0;
		$totalMonths = $intAge * 12 + $intMonth;
		$moYear = $totalMonths / 12;
		$factorAmnw = -61.9 * $moYear;
		$factorAmow = -50.9 * $moYear;
		$factorAfnw = -30.8 * $moYear;
		$factorAfow = -41.2 * $moYear;

		if ($strOverweight == 'yes' && $strGender == 'male') {
			$factorA = $factorAmow;
		} else if ($strOverweight == 'no' && $strGender == 'male') {
			$factorA = $factorAmnw;
		} else if ($strOverweight == 'yes' && $strGender == 'female') {
			$factorA = $factorAfow;
		} else if ($strOverweight == 'no' && $strGender == 'female') {
			$factorA = $factorAfnw;
		}


		$factorMNI = 1.0;
		$factorMNL = 1.13;
		$factorMNM = 1.26;
		$factorMNH = 1.42;

		$factorMOI = 1.0;
		$factorMOL = 1.12;
		$factorMOM = 1.24;
		$factorMOH = 1.45;

		$factorFNI = 1.0;
		$factorFNL = 1.16;
		$factorFNM = 1.31;
		$factorFNH = 1.56;


		$factorFOI = 1.0;
		$factorFOL = 1.18;
		$factorFOM = 1.35;
		$factorFOH = 1.6;

		$malePA = 0;
		if ($strOverweight == 'no' && $strActivity == 'inactive') {
			$malePA = $factorMNI;
		} else if ($strOverweight == 'no' && $strActivity == 'low') {
			$malePA = $factorMNL;
		} else if ($strOverweight == 'no' && $strActivity == 'moderate') {
			$malePA = $factorMNM;
		} else if ($strOverweight == 'no' && $strActivity == 'high') {
			$malePA = $factorMNH;
		} else if ($strOverweight == 'yes' && $strActivity == 'inactive') {
			$malePA = $factorMOI;
		} else if ($strOverweight == 'yes' && $strActivity == 'low') {
			$malePA = $factorMOL;
		} else if ($strOverweight == 'yes' && $strActivity == 'moderate') {
			$malePA = $factorMOM;
		} else if ($strOverweight == 'yes' && $strActivity == 'high') {
			$malePA = $factorMOH;
		}

		$femalePA = 0;
		if ($strOverweight == 'no' && $strActivity == 'inactive') {
			$femalePA = $factorFNI;
		} else if ($strOverweight == 'no' && $strActivity == 'low') {
			$femalePA = $factorFNL;
		} else if ($strOverweight == 'no' && $strActivity == 'moderate') {
			$femalePA = $factorFNM;
		} else if ($strOverweight == 'no' && $strActivity == 'high') {
			$femalePA = $factorFNH;
		} else if ($strOverweight == 'yes' && $strActivity == 'inactive') {
			$femalePA  = $factorFOI;
		} else if ($strOverweight == 'yes' && $strActivity == 'low') {
			$femalePA  = $factorFOL;
		} else if ($strOverweight == 'yes' && $strActivity == 'moderate') {
			$femalePA  = $factorFOM;
		} else if ($strOverweight == 'yes' && $strActivity == 'high') {
			$femalePA  = $factorFOH;
		}

		$factorPA = 0;
		if ($strGender == 'male') {
			$factorPA  = $malePA;
		} else if ($strGender == 'female') {
			$factorPA  = $femalePA;
		}

		$convertWeight = 0;
		$convertPounds = 0.4536;
		$convertKilograms = 1;

		if ($strWeight == 'pounds') {
			$convertWeight = $convertPounds;
		} else if ($strWeight == 'kg') {
			$convertWeight = $convertKilograms;
		}

		$convertKg = $intWeight * $convertWeight;

		$factorW = 0;
		$factorWmnw = 26.7 * $convertKg;
		$factorWmow = 19.5 * $convertKg;
		$factorWfnw = 10 * $convertKg;
		$factorWfow = 15 * $convertKg;

		if ($strOverweight == 'yes' && $strGender == 'male') {
			$factorW = $factorWmow;
		} else if ($strOverweight == 'no' && $strGender == 'male') {
			$factorW = $factorWmnw;
		} else if ($strOverweight == 'yes' && $strGender == 'female') {
			$factorW = $factorWfow;
		} else if ($strOverweight == 'no' && $strGender == 'female') {
			$factorW = $factorWfnw;
		}

		$factorM = 0;
		$factorInches = 0.0254;
		$factorCm = 0.01;
		$factorErr = 1;

		if ($strHeight == 'cm') {
			$factorM = $factorCm;
		} else if ($strHeight == 'inches') {
			$factorM = $factorInches;
		} else {
			$factorM = $factorErr;
		}

		$convertM = intval($intHeight) * $factorM;

		$factorH = 0;
		$factorHmnw = 903 * $convertM;
		$factorHmow = 1161.4 * $convertM;
		$factorHfnw = 934 * $convertM;
		$factorHfow = 701.6 * $convertM;

		if ($strOverweight == 'yes' && $strGender == 'male') {
			$factorH = $factorHmow;
		} else if ($strOverweight == 'no' && $strGender == 'male') {
			$factorH = $factorHmnw;
		} else if ($strOverweight == 'yes' && $strGender == 'female') {
			$factorH = $factorHfow;
		} else if ($strOverweight == 'no' && $strGender == 'female') {
			$factorH = $factorHfnw;
		}

		$factorED = 0;
		$factorEDnine = 25;
		$factorEDeight = 20;
		$factorEDow = 0;

		if ($strOverweight == 'yes') {
			$factorED = $factorEDow;
		} else if ($intAge >= 9) {
			$factorED = $factorEDnine;
		} else {
			$factorED = $factorEDeight;
		}

		$factorPAH = $factorPA * $factorH;
		$factorPAW = $factorPA * $factorW;
		$factorPAHW = $factorPAH + $factorPAW;

		$factorTEE = $factorS + $factorA + $factorPAHW;

		$totalEER = $factorTEE + $factorED;



		$this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Added successfully</div>', 5);
		$this->data['total'] = $totalEER;
		$this->data['breakfast'] = ($totalEER * 20) / 100;
		$this->data['lunch'] = ($totalEER * 26) / 100;
		$this->data['dinner'] = ($totalEER * 26) / 100;
		$this->data['snacks'] =  ($totalEER * 28) / 100;

		$this->data['gender'] = $strGender;
		$this->data['age'] = $intAge;
		$this->data['weight'] = $intWeight;
		$this->data['height'] = $intHeight;
		$this->data['child_id'] = $this->input->post('child_id');
		$this->load->view('calories', $this->data);
		// }
		// $this->data['lunch'] = 0;
		// $this->data['dinner'] = 0;
		// $this->data['breakfast'] = 0;
		// $this->data['snacks'] = 0;
		// $this->data['total'] = 0;



		$this->load->view('calories', $this->data);
	}


	public function about()
	{
		$this->load->view('about');
	}


	public function food($id)
	{
		$details = $this->food->get($id)->row();
		$this->data['id'] = $details->id;
		$this->data['title'] = $details->title;
		$this->data['description'] = $details->description;
		$this->data['photo'] = $details->photo;
		$this->load->view('food', $this->data);
	}
}
