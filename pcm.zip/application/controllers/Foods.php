<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Foods extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
        $this->lang->load('auth');
        $this->load->model('food');
    }

    public function load_data()
    {
        $this->data['foods'] = $this->food->all();
        $this->_render_page('foods/index', $this->data);
    }

    public function index()
    {
        $this->form_validation->set_rules('title', 'Title', 'required', array('required' => 'required'));
        $this->form_validation->set_rules('description', 'description', 'required', array('required' => 'required'));

        if ($this->form_validation->run() == true) {
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $config['upload_path'] = 'uploads';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size']    = '2048';
            $config['file_name'] = $_FILES['photo']['name'];
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('photo')) {
                $uploadData = $this->upload->data();
                $photo = base_url() . "uploads/" . $uploadData['file_name'];
                $data['photo'] = $photo;
            }
            $this->food->add($data);
            $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Added successfully</div>', 5);
            redirect("foods/index", 'refresh');
        } else {
            $this->load_data();
        }
    }

    public function delete($id)
    {
        $this->food->delete($id);
        $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Deleted successfully</div>', 5);
        redirect("foods/index", 'refresh');
    }

    public function details($id)
    {
        $details = $this->food->get($id)->row();
        $this->data['id'] = $details->id;
        $this->data['title'] = $details->title;
        $this->data['description'] = $details->description;
        $this->data['photo'] = $details->photo;
        $this->_render_page('foods/details', $this->data);
    }

    public function edit($id)
    {
        $details = $this->food->get($id)->row();
        $this->data['id'] = $details->id;
        $this->data['title'] = $details->title;
        $this->data['description'] = $details->description;
        $this->data['photo2'] = $details->photo;
        $this->_render_page('foods/edit', $this->data);
    }

    public function update()
    {
        $this->form_validation->set_rules('title', 'Title', 'required', array('required' => 'required'));
        $this->form_validation->set_rules('description', 'description', 'required', array('required' => 'required'));

        if ($this->form_validation->run() == true) {
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $data['photo'] = $this->input->post('photo2');
            $config['upload_path'] = 'uploads';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size']    = '2048';
            $config['file_name'] = $_FILES['photo']['name'];
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('photo')) {
                $uploadData = $this->upload->data();
                $photo = base_url() . "uploads/" . $uploadData['file_name'];
                $data['photo'] = $photo;
            }
            $id = $this->input->post('id');
            $this->food->update($id, $data);
            $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Edited successfully</div>', 5);
            redirect("foods/index", 'refresh');
        } else {
            $this->session->set_tempdata('message', '<div class="alert alert-danger" role="alert">There is a problem with the edit</div>', 5);
            redirect("foods/index", 'refresh');
        }
    }

    public function _render_page($view, $data = NULL, $returnhtml = FALSE)
    {
        $viewdata = (empty($data)) ? $this->data : $data;
        $view_html = $this->load->view($view, $viewdata, $returnhtml);
        if ($returnhtml) {
            return $view_html;
        }
    }
}
