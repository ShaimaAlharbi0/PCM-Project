<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Advices extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
        $this->lang->load('auth');
        $this->load->model('advice');
    }

    public function load_data()
    {
        $this->data['advices'] = $this->advice->all();
        $this->_render_page('advices/index', $this->data);
    }

    public function index()
    {
        $this->form_validation->set_rules('title', 'Title', 'required', array('required' => 'required'));
        $this->form_validation->set_rules('description', 'description', 'required', array('required' => 'required'));

        if ($this->form_validation->run() == true) {
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $this->advice->add($data);
            $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Added successfully</div>', 5);
            redirect("advices/index", 'refresh');
        } else {
            $this->load_data();
        }
    }

    public function delete($id)
    {
        $this->advice->delete($id);
        $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Deleted successfully</div>', 5);
        redirect("advices/index", 'refresh');
    }

    public function details($id)
    {
        $details = $this->advice->get($id)->row();
        $this->data['id'] = $details->id;
        $this->data['title'] = $details->title;
        $this->data['description'] = $details->description;
        $this->_render_page('advices/details', $this->data);
    }

    public function edit($id)
    {
        $details = $this->advice->get($id)->row();
        $this->data['id'] = $details->id;
        $this->data['title'] = $details->title;
        $this->data['description'] = $details->description;
        $this->_render_page('advices/edit', $this->data);
    }

    public function update()
    {
        $this->form_validation->set_rules('title', 'Title', 'required', array('required' => 'required'));
        $this->form_validation->set_rules('description', 'description', 'required', array('required' => 'required'));

        if ($this->form_validation->run() == true) {
            $data['title'] = $this->input->post('title');
            $data['description'] = $this->input->post('description');
            $id = $this->input->post('id');
            $this->advice->update($id, $data);
            $this->session->set_tempdata('message', '<div class="alert alert-success" role="alert">Edited successfully</div>', 5);
            redirect("advices/index", 'refresh');
        } else {
            $this->session->set_tempdata('message', '<div class="alert alert-danger" role="alert">There is a problem with the edit</div>', 5);
            redirect("advices/index", 'refresh');
        }
    }

    public function _render_page($view, $data = NULL, $returnhtml = FALSE)
    {
        $viewdata = (empty($data)) ? $this->data : $data;
        $view_html = $this->load->view($view, $viewdata, $returnhtml);
        if ($returnhtml) {
            return $view_html;
        }
    }
}
