<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Food extends CI_Model
{
    public function all()
    {
        return  $this->db->query("select * from Foods")->result();
    }

    public function get($id)
    {
        return $this->db->query("select * from Foods where id = '$id'");
    }

    public function add($data)
    {
        $this->db->insert('Foods', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('Foods', $data);
    }

    public function delete($id)
    {
        $this->db->query("delete  from Foods where id = '$id' ");
    }
}
