<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Advice extends CI_Model
{
    public function all()
    {
        return  $this->db->query("select * from Advices")->result();
    }

    public function get($id)
    {
        return $this->db->query("select * from Advices where id = '$id'");
    }

    public function add($data)
    {
        $this->db->insert('Advices', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('Advices', $data);
    }

    public function delete($id)
    {
        $this->db->query("delete  from Advices where id = '$id' ");
    }
}
