<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Child extends CI_Model
{
    public function all()
    {
        return  $this->db->query("select * from children")->result();
    }

    public function get($id)
    {
        return $this->db->query("select * from children where id = '$id'");
    }

    public function add($data)
    {
        $this->db->insert('children', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('children', $data);
    }

    public function delete($id)
    {
        $this->db->query("delete from children where id = '$id' ");
    }

    public function getByUser($user_id)
    {
        return  $this->db->query("select * from children where user_id = '$user_id'")->result();
    }

    public function getDetails($id)
    {
        $data = array();
        $this->db->select('*');
        $this->db->where('id', $id);
        $query = $this->db->get('children');
        $data = $query->result_array();
        return $data;
    }
}
